var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.dynabars": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);