/*<<dependency*/
define("sap_viz_ext_colorsliderscatter-src/js/render", ["sap_viz_ext_colorsliderscatter-src/js/utils/util"], function(util){
/*dependency>>*/ 
      
/**
     * This function is a drawing function; you should put all your drawing logic in it.
     * it's called in moduleFunc.prototype.render
     * @param {Object} data - data set passed in
     * @param {Object} container - target DOM element (SVG or DIV) of the plot area to render in
     * @param {float} width - width of canvas
     * @param {float} height - height of canvas
     * @param {Array of color string} colorPalette - color palette
     * @param {Object} properties - properties of chart
     * @param {Object} dispatch - event dispatcher
*/
     
/*
  This is the D3 scatter from mbostock, adapted for Lumira by kpereyra
  The git package contains two datasets: 
    * mbostock's iris data http://bl.ocks.org/mbostock/3887118
    * OldFaithful dataset http://www.stat.cmu.edu/~larry/all-of-statistics/=data/faithful.dat
      with an arbitrary DayOfWeek column added to be used as a legend
      
  The git package also contains screen-captures of VizPacker (3 jpg files)
  to demonstrate which combination of measures and dimensions will 
  result in the desired appearance for your data.
*/
     
    var render = function(data, container, width, height, colorPalette, properties, dispatch) {
    		//prepare canvas with width and height of container
    		container.selectAll('svg').remove();
        var vis = container.append('svg').attr('width', width).attr('height', height)
                        .append('g').attr('class', 'vis').attr('width', width).attr('height', height);
          
        var dsets = data.meta.dimensions(),
            msets = data.meta.measures();
        
        // a single measure for the horizontal axis
        var mset1 = data.meta.measures(0); 
        var ms1 = mset1[0];  
        
        // three measures for the y-axis, dot labels, and color/legend
        var dset1 = data.meta.dimensions(0); 
        var ds_yAxis = dset1[0]; 
        var ds_label = dset1[1]; 
        var ds_color = dset1[2]; 
    
        // since this scatter has multiple values per y-axis item,
        // get a unique list of y-axis labels to avoid duplication
        var yAxisValues = stackCategories (data, ds_yAxis);  
        var textWidth = 70;
        
        // Constants for chart layout
        var dotAttr = {
          size: 7,
          fontSize: 8,
          labelOffset: 6
        };
        // idea: set these based on the font size of the axis labels
        
        var legendAttr = {
            width: textWidth+80,
            rowSpacing: 20,
            blockSize: 18,
            textRightMargin: 5
        };
        
        var margin = {
            top: 20,
            right: legendAttr.width,
            bottom: 30,
            left: textWidth
        };
        
        var plotWidth = width - margin.left - margin.right,
            plotHeight = height - margin.top - margin.bottom;
            
        //shift plot area to clear out the margins
        vis.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
        
        // format axes: measure along the bottom
        // y-axis labeled with text along both right and left, for readability
        // tick marks on y-axis go all the way across to clearly mark the dots
        // that belong to each y-axis item
        var x = d3.scale.linear()
            .range([0, plotWidth]);
        
        var y = d3.scale.linear()
            .range([plotHeight, 0]);
        var xAxis = d3.svg.axis()
            .scale(x)
            .orient("bottom");
        
        var yAxisRight = d3.svg.axis()
            .scale(y)
            .tickSize(plotWidth,0)
            .ticks(yAxisValues.length)
            .tickFormat(function(d,i) { return yAxisValues[i]; })
            .orient("right");
            
        var yAxisLeft = d3.svg.axis()
            .scale(y)
            .tickSize(0)
            .ticks(yAxisValues.length)
            .tickFormat(function(d,i) { return yAxisValues[i]; })
            .orient("left");
              
        
         var color = d3.scale.category10();
          
        x.domain(d3.extent(data, function(d) {return d[ms1]; })).nice();      
        y.domain(d3.extent(yAxisValues, function(d,i) { return i; })).nice();   // use the index of the unique list of y-axis values
      
        vis.append("g")
            .attr("class", "x axis")
            .attr("transform", "translate(0," + plotHeight + ")")
            .call(xAxis)
          .append("text")
            .attr("class", "label")
            .attr("x", plotWidth)
            .attr("y", margin.bottom/2)
            .style("text-anchor", "end")
            .text(ms1);
            
        vis.append("g")
            .attr("class", "y axis")
            .call(yAxisRight)
       
        vis.append("g")
            .attr("class", "y axis")
            .call(yAxisLeft)
          .append("text")
            .attr("class", "axisLabel")
            .attr("y", -1*margin.top)
            .attr("dy", ".71em")
            .style("text-anchor", "end")
            .text(ds_yAxis)
   
       // dots area added indirectly through a g object item
       // to allow appending text labels
       var dots = vis.selectAll(".dot")
            .data(data)
          .enter().append("g");
        
       dots.append("circle")
            .attr("class", "dot")
            .attr("r", dotAttr.size)
            .attr("cx", function(d) { return x(d[ms1]); })
            .attr("cy", function(d) { return y(yAxisValues.indexOf(d[ds_yAxis])); })
            .style("fill", function(d) { return color(d[ds_color]); })
            .append("title")
            .text(function(d) { 
              var xAxisLabel=ms1+": "+d[ms1];
              var yAxisLabel=ds_yAxis+": "+d[ds_yAxis];
              var colorLabel=ds_color+": "+d[ds_color];
              var dotLabel=ds_label+": "+d[ds_label];
              return yAxisLabel+"\n"+dotLabel+"\n"+xAxisLabel+"\n"+colorLabel; })
            .on("click", function(d, i) {
                console.log('click'); 
                console.log(d);
                console.log(i);
                //dispatch.barData(d);
                //util.fireSelectDataEvent(dispatch, ms1, d, i);
            });
        
        dots.append("text")
          .attr("x", function(d) { return x(d[ms1]); })
          .attr("y", function(d) { return y(yAxisValues.indexOf(d[ds_yAxis]))-dotAttr.labelOffset; })
          .text(function(d) { return d[ds_label]; })
          .style("text-anchor", "middle")
          .style("font-size", dotAttr.fontSize);
      
      // add the color legend on the right, in the wide margin
      // see also: "Constants for chart layout" where we set the legend attributes legendAttr 
        var legend = vis.selectAll(".legend")
            .data(color.domain())
          .enter().append("g")
            .attr("class", "legend")
            .attr("transform", function(d, i) { return "translate(0," + i * legendAttr.rowSpacing + ")"; });
      console.log(legend);
        legend.append("rect")
            .attr("x", plotWidth + legendAttr.width-legendAttr.blockSize)
            .attr("width", legendAttr.blockSize)
            .attr("height", legendAttr.blockSize)
            .style("fill", color);
      
        legend.append("text")
            .attr("x", plotWidth + legendAttr.width -legendAttr.blockSize- legendAttr.textRightMargin)
            .attr("y", 9)
            .attr("dy", ".35em")
            .style("text-anchor", "end")
            .text(function(d) { return d; });
        
    // END: sample render code
    };
    
    function stackCategories (data, dimensionName) {

    var returnMe = [];
        
    data.forEach(function (d) {
      dimensionValue = d[dimensionName];
      if (!dimensionValue) {dimensionValue = ""};
      if (returnMe.indexOf(dimensionValue)==-1) { 
        returnMe.push(dimensionValue);
      }
    });
    returnMe.sort();  // for example, if labelVar is Country, array contains China, Japan, Korea
    
    return returnMe;
}

    return render; 
});