var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.affinity": {
			"legend": {
				"title": {
					"visible": true
				}
			}
		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);