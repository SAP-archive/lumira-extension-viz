var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.stackedcolumnlinechart": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);