var sampleTemplate = 
{
    "id": "standard",
    "name": "Standard",
    "properties": {
        "sap.viz.ext.minidonutchart": {
            
        }
    }
};
sap.viz.extapi.env.Template.register(sampleTemplate);