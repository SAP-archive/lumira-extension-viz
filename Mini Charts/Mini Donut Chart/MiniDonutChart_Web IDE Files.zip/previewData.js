define([], function() {
    var previewData = {
        cross: {"data":{"measureValuesGroup":[{"index":1,"data":[{"type":"Measure","name":"Percentage","values":[[0.73]]}]}]},"bindings":[{"feed":"sap.viz.ext.minidonutchart.PlotModule.MS1","source":[{"type":"measureValuesGroup","index":1}]}]},
        flat: {"metadata":{"dimensions":[],"measures":[{"name":"Percentage","value":"{Percentage}"}],"data":{"path":"/data"}},"feedItems":[{"uid":"sap.viz.ext.minidonutchart.PlotModule.MS1","type":"Measure","values":["Percentage"]}],"data":{"data":[{"Percentage":0.73}]}}
    };
    return previewData;
});