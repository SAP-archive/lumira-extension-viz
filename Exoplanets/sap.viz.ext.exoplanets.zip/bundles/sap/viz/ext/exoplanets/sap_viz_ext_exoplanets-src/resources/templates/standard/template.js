var sampleTemplate = 
{
    "id": "standard",
    "name": "Standard",
    "properties": {
        "sap.viz.ext.exoplanets": {
            
        }
    }
};
sap.viz.extapi.env.Template.register(sampleTemplate);