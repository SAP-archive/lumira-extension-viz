var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.geomapsleaflet": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);