var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.potentialperformance": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);