var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.bitcoins": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);