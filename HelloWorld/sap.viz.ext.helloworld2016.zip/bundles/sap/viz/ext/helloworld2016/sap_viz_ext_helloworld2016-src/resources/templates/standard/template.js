var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.helloworld2016": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);