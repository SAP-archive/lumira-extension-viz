var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.chordchart": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);