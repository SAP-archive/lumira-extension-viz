var sampleTemplate = 
{
    "id": "standard",
    "name": "Standard",
    "properties": {
        "ucs.viz.ext.gauge": {
            
        }
    }
};
sap.viz.extapi.env.Template.register(sampleTemplate);