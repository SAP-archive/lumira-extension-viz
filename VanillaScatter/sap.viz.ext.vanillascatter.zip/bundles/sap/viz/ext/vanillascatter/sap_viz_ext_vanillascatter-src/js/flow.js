/*<<dependency*/
define("sap_viz_ext_vanillascatter-src/js/flow", [ "sap_viz_ext_vanillascatter-src/js/module" ], function(moduleFunc) {
/*dependency>>*/
    var flowRegisterFunc = function(){
		var flow = sap.viz.extapi.Flow.createFlow({
			id : "sap.viz.ext.vanillascatter",
			name : "Vanilla Scatter",
			dataModel : "sap.viz.api.data.CrosstableDataset",
			type : "BorderSVGFlow"
		});
		var titleElement  = sap.viz.extapi.Flow.createElement({
			id : "sap.viz.chart.elements.Title",
			name : "Title"
		});
		flow.addElement({
			"element" : titleElement,
			"propertyCategory" : "title",
			"place" : "top"
		});
		var element  = sap.viz.extapi.Flow.createElement({
			id : "sap.viz.ext.module.VanillaScatterModule",
			name : "VanillaScatter"
		});
		element.implement("sap.viz.elements.common.BaseGraphic", moduleFunc);
		/*Feeds Definition*/
		//ds1: species, petalWidth
		var ds1 = {
		    "id": "sap.viz.ext.module.VanillaScatterModule.DS1",
		    "name": "X Axis",
		    "type": "Dimension",
		    "min": 1,
		    "max": 2,
		    "aaIndex": 1,
		    "minStackedDims": 1,
		    "maxStackedDims": Infinity
		};
		element.addFeed(ds1);
		
		//ms1: sepalLength, sepalWidth, petalLength
		var ms1 = {
		    "id": "sap.viz.ext.module.VanillaScatterModule.MS1",
		    "name": "Y Axis",
		    "type": "Measure",
		    "min": 1,
		    "max": Infinity,
		    "mgIndex": 1
		};
		element.addFeed(ms1);
		
		flow.addElement({
			"element":element,
			"propertyCategory" : "plotArea"
		});
		sap.viz.extapi.Flow.registerFlow(flow);
    };
    flowRegisterFunc.id = "sap.viz.ext.vanillascatter";
    return {
        id : flowRegisterFunc.id,
        init : flowRegisterFunc
    };
});