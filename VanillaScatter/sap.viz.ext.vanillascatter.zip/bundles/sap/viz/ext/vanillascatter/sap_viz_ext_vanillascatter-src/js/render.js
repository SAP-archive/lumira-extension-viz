/*<<dependency*/
define("sap_viz_ext_vanillascatter-src/js/render", ["sap_viz_ext_vanillascatter-src/js/utils/util"], function(util){
/*dependency>>*/ 
  
/**
     * This function is a drawing function; you should put all your drawing logic in it.
     * it's called in moduleFunc.prototype.render
     * @param {Object} data - data set passed in
     * @param {Object} container - target DOM element (SVG or DIV) of the plot area to render in
     * @param {float} width - width of canvas
     * @param {float} height - height of canvas
     * @param {Array of color string} colorPalette - color palette
     * @param {Object} properties - properties of chart
     * @param {Object} dispatch - event dispatcher
     */
     
     //This is the D3 scatter from mbostock.  
     //Use a number column as dimension, and it comes out just like his.
     //Use the text "species" column as dimension, and it plots just the three poitns.
     
    var render = function(data, container, width, height, colorPalette, properties, dispatch) {
		//prepare canvas with width and height of container
		container.selectAll('svg').remove();
        var vis = container.append('svg').attr('width', width).attr('height', height)
                    .append('g').attr('class', 'vis').attr('width', width).attr('height', height);
                    
      //console.log (data);
      
        var dsets = data.meta.dimensions(),
            msets = data.meta.measures();
        
        var mset1 = data.meta.measures(0); 
        var ms1 = mset1[0];  
        var ms2 = mset1[1];
        //console.log ('The measures are "'+ms1+'" and "'+ms2+'"');
                
        var dset1 = data.meta.dimensions(0); 
        var ds1 = dset1[0]; 
        //console.log ('The dimension is "'+ds1+'"'); 


        
        var legendAttr = {
            width: 80,
            rowSpacing: 20,
            blockSize: 18,
            textRightMargin: 5
        };
        
        var margin = {
            top: 20,
            right: legendAttr.width,
            bottom: 60,
            left: 40
        };
        
        var plotWidth = width - margin.left - margin.right,
            plotHeight = height - margin.top - margin.bottom;
            
        //transform plot area
        vis.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
        
        //get the max of each measure and plot it versus the width and height, for spacing
        max_ms1 = 0;
        max_ms2 = 0;
        for (i=0; i< data.length; i++) {
          if (data[i][ms1] > max_ms1) {max_ms1 = data[i][ms1]} ;
          if (data[i][ms2] > max_ms2) {max_ms2 = data[i][ms2]} ;
        }
        factor_ms1 = max_ms1/(.9*plotWidth); 
        factor_ms2 = max_ms2/(.9*plotHeight);
           
var x = d3.scale.linear()
    .range([0, plotWidth]);

var y = d3.scale.linear()
    .range([plotHeight, 0]);
var xAxis = d3.svg.axis()
    .scale(x)
    .orient("bottom");

var yAxis = d3.svg.axis()
    .scale(y)
    .orient("left");
    
var color = d3.scale.category10();
    
  x.domain(d3.extent(data, function(d) {return d[ms2]; })).nice();      
  y.domain(d3.extent(data, function(d) { return d[ms1]; })).nice();   

  vis.append("g")
      .attr("class", "x axis")
      .attr("transform", "translate(0," + plotHeight + ")")
      .call(xAxis)
    .append("text")
      .attr("class", "label")
      .attr("x", plotWidth)
      .attr("y", -6)
      .style("text-anchor", "end")
      .text(ms2);
      
  vis.append("g")
      .attr("class", "y axis")
      .call(yAxis)
    .append("text")
      .attr("class", "label")
      .attr("transform", "rotate(-90)")
      .attr("y", 6)
      .attr("dy", ".71em")
      .style("text-anchor", "end")
      .text(ms1)

  vis.selectAll(".dot")
      .data(data)
    .enter().append("circle")
      .attr("class", "dot")
      .attr("r", 3.5)
      .attr("cx", function(d) { return x(d[ms2]); })
      .attr("cy", function(d) { return y(d[ms1]); })
      .style("fill", function(d) { return color(d[ds1]); });

  var legend = vis.selectAll(".legend")
      .data(color.domain())
    .enter().append("g")
      .attr("class", "legend")
      .attr("transform", function(d, i) { return "translate(0," + i * legendAttr.rowSpacing + ")"; });

  legend.append("rect")
      .attr("x", plotWidth + legendAttr.width-legendAttr.blockSize)
      .attr("width", legendAttr.blockSize)
      .attr("height", legendAttr.blockSize)
      .style("fill", color);

  legend.append("text")
      .attr("x", plotWidth + legendAttr.width -legendAttr.blockSize- legendAttr.textRightMargin)
      .attr("y", 9)
      .attr("dy", ".35em")
      .style("text-anchor", "end")
      .text(function(d) { return d; });

// END: sample render code
    };

    return render; 
});