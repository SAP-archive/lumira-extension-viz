/*<<dependency*/
define("sap_viz_ext_lossincidentoptimization-src/js/flow", [ "sap_viz_ext_lossincidentoptimization-src/js/module" ], function(moduleFunc) {
/*dependency>>*/
    var flowRegisterFunc = function(){
		var flow = sap.viz.extapi.Flow.createFlow({
			id : 'sap.viz.ext.lossincidentoptimization',
			name : 'Loss Incident Optimization',
			dataModel : 'sap.viz.api.data.CrosstableDataset',
			type : 'BorderSVGFlow'
		});
		var titleElement  = sap.viz.extapi.Flow.createElement({
			id : 'sap.viz.chart.elements.Title',
			name : 'Title',
		});
		flow.addElement({
			'element':titleElement,
			'propertyCategory':'title',
			'place':'top'
		});
		var element  = sap.viz.extapi.Flow.createElement({
			id : 'sap.viz.ext.module.LossIncidentOptimization',
			name : 'Loss Incident Optimization',
		});
		element.implement('sap.viz.elements.common.BaseGraphic', moduleFunc);
		/*Feeds Definition*/
		//ds1: Date
		var ds1 = {
		    "id": "sap.viz.ext.module.LossIncidentOptimization.DS1",
		    "name": "Date",
		    "type": "Dimension",
		    "min": 1,
		    "max": 1,
		    "aaIndex": 1,
		    "minStackedDims": 1,
		    "maxStackedDims": 1
		};
		//ds2: Time
		var ds2 = {
		    "id": "sap.viz.ext.module.LossIncidentOptimization.DS2",
		    "name": "Time",
		    "type": "Dimension",
		    "min": 1,
		    "max": 1,
		    "aaIndex": 2,
		    "minStackedDims": 1,
		    "maxStackedDims": 1
		};
		//ms1: Claim
		var ms1 = {
		    "id": "sap.viz.ext.module.LossIncidentOptimization.MS1",
		    "name": "Claim",
		    "type": "Measure",
		    "min": 1,
		    "max": 1,
		    "mgIndex": 1
		};
		element.addFeed(ds1);
		element.addFeed(ds2);
		element.addFeed(ms1);
		flow.addElement({
			'element':element,
			'propertyCategory' : 'Loss Incident Optimization'
		});
		sap.viz.extapi.Flow.registerFlow(flow);
    };
    flowRegisterFunc.id = 'sap.viz.ext.lossincidentoptimization';
    return {
        id : flowRegisterFunc.id,
        init : flowRegisterFunc
    };
});