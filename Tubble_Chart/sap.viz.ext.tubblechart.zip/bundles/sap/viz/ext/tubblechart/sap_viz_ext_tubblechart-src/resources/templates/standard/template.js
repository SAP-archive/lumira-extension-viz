var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.tubblechart": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);