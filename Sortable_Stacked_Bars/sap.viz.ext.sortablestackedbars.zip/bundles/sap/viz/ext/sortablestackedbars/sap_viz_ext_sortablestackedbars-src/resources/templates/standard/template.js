var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.sortablestackedbars": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);