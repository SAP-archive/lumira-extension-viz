var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.forecastsingle": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);