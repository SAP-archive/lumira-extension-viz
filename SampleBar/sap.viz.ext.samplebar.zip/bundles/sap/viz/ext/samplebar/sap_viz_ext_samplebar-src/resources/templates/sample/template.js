var sampleTemplate = 
{
    "id": "sample",
    "name": "Sample",
    "properties": {
        "sap.viz.ext.samplebar": {
            "legend": {
                "title": {
                    "visible": true
                }
            }
        }
    }
};
sap.viz.extapi.env.Template.register(sampleTemplate);