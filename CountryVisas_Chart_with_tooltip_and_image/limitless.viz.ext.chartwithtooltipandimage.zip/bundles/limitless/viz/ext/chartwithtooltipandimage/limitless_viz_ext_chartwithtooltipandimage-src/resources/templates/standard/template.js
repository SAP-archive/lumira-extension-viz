var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"limitless.viz.ext.chartwithtooltipandimage": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);