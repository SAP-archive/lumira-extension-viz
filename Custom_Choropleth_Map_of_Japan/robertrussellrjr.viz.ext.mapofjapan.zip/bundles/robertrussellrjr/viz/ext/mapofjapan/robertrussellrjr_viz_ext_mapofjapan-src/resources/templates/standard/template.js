var sampleTemplate = 
{
    "id": "standard",
    "name": "Standard",
    "properties": {
        "robertrussellrjr.viz.ext.mapofjapan": {
            
        }
    }
};
sap.viz.extapi.env.Template.register(sampleTemplate);