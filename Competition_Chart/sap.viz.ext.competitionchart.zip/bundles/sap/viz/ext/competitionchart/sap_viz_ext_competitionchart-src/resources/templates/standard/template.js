var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.competitionchart": {
			"legend": {
				"title": {
					"visible": true
				}
			}
		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);