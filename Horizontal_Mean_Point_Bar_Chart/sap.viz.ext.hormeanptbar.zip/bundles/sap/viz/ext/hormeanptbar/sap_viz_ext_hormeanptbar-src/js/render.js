define("sap_viz_ext_hormeanptbar-src/js/render", [], function() {
	/*
	 * This function is a drawing function; you should put all your drawing logic in it.
	 * it's called in moduleFunc.prototype.render
	 * @param {Object} data - proceessed dataset, check dataMapping.js
	 * @param {Object} container - the target d3.selection element of plot area
	 * @example
	 *   container size:     this.width() or this.height()
	 *   chart properties:   this.properties()
	 *   dimensions info:    data.meta.dimensions()
	 *   measures info:      data.meta.measures()
	 */
	var render = function(data, container) {
	// TODO: add your own visualization implementation code below ...
		var width = this.width(),
			height = this.height(),
			colorPalette = this.properties().colorPalette,
			percentTittle = "% Better or Worse than Average";
			
		var margin = {  top: 50, right: 10,	bottom: 10,	left: 30},
			plotWidth = width - margin.left - margin.right,
			plotHeight = height - margin.top - margin.bottom;
			
		var color = d3.scale.ordinal().range(colorPalette);

		//prepare canvas with width and height of container	
		container.selectAll('svg').remove();
		
		var svg = container.append('svg').attr('width', width).attr('height', height)
					.append('g')
					.attr("class", "sap_viz_ext_hormeanptbar")
				//	.attr("width", plotWidth).attr("height", plotHeight)
					.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
						           
		// START: sample render code for a column chart
		// Replace the code below with your own one to develop a new extension

		var dims = data.meta.dimensions(),  // ["Brand", "Model", "category"]
			scores = data.meta.measures();
	// ["Overall Dependability", "Powertrain  Dependability", "Body & Interior Dependability", "Feature & Accessory Dependability"]
		
		var dataset = NestDataSet(data);
		
		var MeanPointBar = new DrawMeanPtBar(dataset);
		var yAxisWidth = MeanPointBar.DrawAxis(plotWidth, plotHeight, dataset.max_val);
		MeanPointBar.DrawBrandBar();
		MeanPointBar.UpdateAxis(width - margin.right - yAxisWidth, plotHeight, yAxisWidth);
		MeanPointBar.UpdateBrandBar(width - margin.right - yAxisWidth);
		
		console.log(yAxisWidth);
  
	function NestDataSet(_data){
		_data.forEach(function(d) {
        	d["DependTotal"] = (function(){
        		var deptotal = 0;
        		for(var i = 0; i < scores.length ; i++){
        			deptotal += d[scores[i]];
        		}
        		return deptotal;
        	})();
    	});
		var _nest_data = d3.nest()
			.key(function(d) {  return d[dims[0]]; })
			.entries(_data);
			
		_nest_data.forEach(function(d) {
        	d["mean_Depend"] = (function(){
        		var allmodeldep = 0;
        		for(var i = 0; i < d.values.length ; i++){
        			allmodeldep += d.values[i]["DependTotal"];
        		}
        		return allmodeldep/d.values.length;
        	})();
        	d["min_Depend"] = d3.min(d.values, function(obj) {  return obj["DependTotal"];  });
        	d["max_Depend"] = d3.max(d.values, function(obj) {  return obj["DependTotal"];  });
    	});
    	
    	_nest_data.sort(function(a,b){ 
    		if (a["mean_Depend"] > b["mean_Depend"]) {   return -1; }
			if (a["mean_Depend"] < b["mean_Depend"]) {   return 1; }
			return 0;
    	});
    	
    	var brandDependTotal = 0;
		var _minVal = d3.min(data, function(d) {  brandDependTotal += d["DependTotal"]; return d["DependTotal"];  });
		var _maxVal = d3.max(data, function(d) {  return d["DependTotal"];  });
		
		_nest_data["BrandDependMean"] =  brandDependTotal / data.length;
		console.log("Min Val: " + _minVal + "; Max Val: " + _maxVal);
			
		console.log(_nest_data);
		
		return {
			nest_data: _nest_data,
			min_val: _minVal,
			max_val: _maxVal
		};
	}
	
	function DrawMeanPtBar(newdataset){
		var x = d3.scale.linear(),
			y = d3.scale.ordinal(),
			yBrandList;
			
		var xAxisContainer, yAxisContainer,
			xAxis, yAxis,
			yAxisWid = 0 ;
		
		this.DrawAxis = function(_plotWidth, _plotHeight, maxVal){
			x.rangeRound([0, _plotWidth]);
			y.rangeRoundBands([0, _plotHeight], .3);
			var xMeanVal = newdataset.nest_data["BrandDependMean"].toFixed(2);
			
			xAxis = d3.svg.axis().scale(x).orient("top")
						.tickFormat(function(d) { 
							var offPercent = (d - xMeanVal ) * 100 / (maxVal - xMeanVal);
							return Math.floor(offPercent) + "%"; 
						});
			yAxis = d3.svg.axis().scale(y).orient("left");
			
			x.domain([newdataset.min_val - 1, newdataset.max_val + 1]).nice();
			y.domain(newdataset.nest_data.map(function(d) { 
				return d.key +" ("+ d.values.length +")"; 
			}));
			yBrandList = y.domain();
			
			xAxisContainer = svg.append("g")
					.attr("class", "x sap_viz_ext_hormeanptbar_axis").call(xAxis);
	    	yAxisContainer = svg.append("g")
	    			.attr("class", "y sap_viz_ext_hormeanptbar_axis").call(yAxis);
	    	
	    	yAxisWid = svg.select(".y.sap_viz_ext_hormeanptbar_axis").node().getBBox().width;
	    	
	    	return yAxisWid;
		};
		//.node().getBBox().width;
		
		var brandList = svg.append("g").attr("class", "sap_viz_ext_hormeanptbar_brandList"),
			brandBar;
		
		this.DrawBrandBar = function(){
			brandBar = brandList.selectAll(".sap_viz_ext_hormeanptbar_brandBar")
	    		.data(newdataset.nest_data)
	    		.enter()
	    		.append("g")
	    		.attr("class", "sap_viz_ext_hormeanptbar_brandBar")
	    		.attr("transform", function(d,i) { return "translate(0," + y(yBrandList[i]) + ")"; });
			
			brandBar.append("rect")
				.attr("class", "sap_viz_ext_hormeanptbar_brandRect")
				.attr("width", plotWidth)
				.attr("height", y.rangeBand())
				.attr("x", "1")
				.attr("y", 0 )
				.attr("fill-opacity", "0.5")
				.style("fill", "#F5F5F5");
	          //.attr("class", function(d,index) { return index%2==0 ? "even" : "uneven"; });
	          
			brandBar.append("rect")
				.attr("class", "sap_viz_ext_hrztmeanptbar_depRangeScore")
				.attr("width", function(d){ return x(d["max_Depend"]) - x(d["min_Depend"]); })
				.attr("height", y.rangeBand())
				.attr("x", function(d){ return x(d["min_Depend"]); })
				.attr("y", 0 )
				.attr("fill-opacity", "0.7")
				.style("fill", "#086fad");
				// .style("fill", function(d){ return color(d.key); });
			
			brandBar.append("circle")
				.attr("class", "sap_viz_ext_hormeanptbar_depMeanPoint")
				.attr("r", y.rangeBand()*.8/2)
				.attr("cx", function(d) { return x(d["mean_Depend"]); })
	    		.attr("cy", y.rangeBand()/2)
				.style("fill", "#FFE066");
			
			svg.append("line")
				.attr("class", "sap_viz_ext_hormeanptbar_depMeanLine")
				.attr("x1", x(newdataset.nest_data["BrandDependMean"]))
				.attr("x2", x(newdataset.nest_data["BrandDependMean"]))
				.attr("y1", 0)
				.attr("y2", plotHeight)
				.attr("stroke-dasharray", "10,10");	
		}; // DrawBrandBar()
		
		this.UpdateAxis = function(_plotWidth, _plotHeight, AxisOffset){
			x.rangeRound([0, _plotWidth]);
			y.rangeRoundBands([0, _plotHeight], .3);
			
			xAxis.scale(x);
			yAxis.scale(y);
			
			xAxisContainer.call(xAxis);
			yAxisContainer.call(yAxis);
			
			var hintTittle = xAxisContainer.append("g").attr("width", _plotWidth);

			hintTittle.append("text")
				.attr("class", "x_axis_percentTittle")
				.attr("dy", "-2em")
				.attr("dx", "50%")
				.attr("fill", "#333")
				.text(percentTittle);
				
			hintTittle.append("text")
				.attr("class", "x_axis_meanPoint")
				.attr("dy", "-.8em")
				.attr("dx", function(){
					return xAxisContainer.select("path.domain").node().getBBox().width/2;
				})
				.attr("font-weight", "bold")
				.attr("font-size", "1.5em")
				.attr("fill", "rgba(60,60,60, .8)")
				.text("0");
			
			container.select(".sap_viz_ext_hormeanptbar")
				.attr("transform", "translate(" + AxisOffset + "," + margin.top + ")");
		};
		
		this.UpdateBrandBar = function(_plotWidth){
			var brandBarRect = brandBar.selectAll(".sap_viz_ext_hormeanptbar_brandRect");
			var brandBarItem = brandBar.selectAll(".sap_viz_ext_hrztmeanptbar_depRangeScore");
			var brandBarPoint = brandBar.selectAll(".sap_viz_ext_hormeanptbar_depMeanPoint");
			
			brandBarRect.attr("width", _plotWidth);
			brandBarItem.attr("width", function(d){ return x(d["max_Depend"]) - x(d["min_Depend"]); })
				.attr("x", function(d){ return x(d["min_Depend"]); });
			brandBarPoint.attr("cx", function(d) { return x(d["mean_Depend"]); });
			
			color.domain(data.map(function(d) {
				return d[dims[2]]; 
			}));
			console.log(color.domain());
		};
		
	}
	}; // render()

	return render;
});