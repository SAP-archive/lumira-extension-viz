define("sap_viz_ext_hormeanptbar-src/js/render", [], function() {
	/*
	 * This function is a drawing function; you should put all your drawing logic in it.
	 * it's called in moduleFunc.prototype.render
	 * @param {Object} data - proceessed dataset, check dataMapping.js
	 * @param {Object} container - the target d3.selection element of plot area
	 * @example
	 *   container size:     this.width() or this.height()
	 *   chart properties:   this.properties()
	 *   dimensions info:    data.meta.dimensions()
	 *   measures info:      data.meta.measures()
	 */
	var render = function(data, container) {
	// TODO: add your own visualization implementation code below ...
		var width = this.width(),
			height = this.height(),
			colorPalette = this.properties().colorPalette,
			percentTittle = "% Better or Worse than Average";
			
		var margin = {  top: 50, right: 10,	bottom: 10,	left: 30},
			plotWidth = width - margin.left - margin.right,
			plotHeight = height - margin.top - margin.bottom;
			
		var color = d3.scale.ordinal().range(colorPalette);

		//prepare canvas with width and height of container	
		container.selectAll('svg').remove();
		
		var svg = container.append('svg').attr('width', width).attr('height', height)
					.append('g')
					.attr("class", "sap_viz_ext_hormeanptbar")
				//	.attr("width", plotWidth).attr("height", plotHeight)
					.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
						           
		// START: sample render code for a column chart
		// Replace the code below with your own one to develop a new extension

		var dims = data.meta.dimensions(),  // ["Brand", "Model", "category"]
			scores = data.meta.measures();
	// ["Overall Dependability", "Powertrain  Dependability", "Body & Interior Dependability", "Feature & Accessory Dependability"]
		
		var dataset = NestDataSet(data);
		
		var MeanPointBar = new DrawMeanPtBar(dataset);
		var yAxisWidth = MeanPointBar.DrawAxis(plotWidth, plotHeight, dataset.max_val);
		MeanPointBar.DrawBrandBar();
		MeanPointBar.UpdateAxis(width - margin.right - yAxisWidth, plotHeight, yAxisWidth);
		MeanPointBar.UpdateBrandBar(width - margin.right - yAxisWidth);
		
		// console.log("yAxisWidth: " + yAxisWidth);
  
	function NestDataSet(_data){
		_data.forEach(function(d) {
        	d["DependTotal"] = (function(){
        		var deptotal = 0;
        		for(var i = 0; i < scores.length ; i++){
        			deptotal += d[scores[i]];
        		}
        		return deptotal;
        	})();
    	});
		var _nest_data = d3.nest()
			.key(function(d) {  return d[dims[0]]; })
			.entries(_data);
			
		_nest_data.forEach(function(d) {
        	d["mean_Depend"] = (function(){
        		var allmodeldep = 0;
        		for(var i = 0; i < d.values.length ; i++){
        			allmodeldep += d.values[i]["DependTotal"];
        		}
        		return allmodeldep/d.values.length;
        	})();
        	d["min_Depend"] = d3.min(d.values, function(obj) {  return obj["DependTotal"];  });
        	d["max_Depend"] = d3.max(d.values, function(obj) {  return obj["DependTotal"];  });
    	});
    	
    	_nest_data.sort(function(a,b){ 
    		if (a["mean_Depend"] > b["mean_Depend"]) {   return -1; }
			if (a["mean_Depend"] < b["mean_Depend"]) {   return 1; }
			return 0;
    	});
    	
    	var brandDependTotal = 0;
		var _minVal = d3.min(data, function(d) {  brandDependTotal += d["DependTotal"]; return d["DependTotal"];  });
		var _maxVal = d3.max(data, function(d) {  return d["DependTotal"];  });
		
		_nest_data["BrandDependMean"] =  brandDependTotal / data.length;
        
		// console.log(_nest_data);
		
		return {
			nest_data: _nest_data,
			min_val: _minVal,
			max_val: _maxVal
		};
	}
	
	function DrawMeanPtBar(newdataset){
		var x = d3.scale.linear(),
			y = d3.scale.ordinal(),
			yBrandList;
			
		var xAxisContainer = svg.append("g").attr("class", "x sap_viz_ext_horMeanPtBar_axis"),
			yAxisContainer = svg.append("g").attr("class", "y sap_viz_ext_horMeanPtBar_axis"),
			xAxisHintContainer = svg.append("g").attr("class", "x sap_viz_ext_horMeanPtBar_axis_hint"),
			xAxisFullHeight, xAxis, yAxis,
			yAxisWid = 0 ;
		
		this.DrawAxis = function(_plotWidth, _plotHeight, maxVal){
			x.rangeRound([0, _plotWidth]);
			y.rangeRoundBands([0, _plotHeight], .3);

			x.domain([newdataset.min_val, newdataset.max_val]).nice();
			y.domain(newdataset.nest_data.map(function(d) { 
				return d.key +" ("+ d.values.length +")"; 
			}));
			yBrandList = y.domain();
            var xRanges = d3.range(x.domain()[0], x.domain()[1] + 2, 2);
            newdataset.xMeanVal = xRanges[ Math.ceil( (xRanges.indexOf(x.domain()[1]) - xRanges.indexOf(x.domain()[0]))/2 ) ];
			
			xAxis = d3.svg.axis().scale(x).orient("top")
							.ticks(11)
							.tickFormat(function(d, i) { 
								var offPercent = (d - newdataset.xMeanVal ) / (x.domain()[1] - newdataset.xMeanVal) * 100;
								// console.log(i + ", offPercent: " + offPercent + ", d " + d);
								return Math.floor(offPercent) + "%"; 
							});
			xAxisFullHeight = d3.svg.axis().scale(x).orient("bottom")
							.ticks(11)
							.tickSize(_plotHeight);
							
			yAxis = d3.svg.axis().scale(y).orient("left");
			
			xAxisContainer.call(xAxis);
			yAxisContainer.call(yAxis);
			xAxisHintContainer.call(xAxisFullHeight);
	    	
	    	yAxisWid = svg.select(".y.sap_viz_ext_horMeanPtBar_axis").node().getBBox().width;
	    	
	    	return yAxisWid;
		};
		//.node().getBBox().width;
		
		var brandList = svg.append("g").attr("class", "sap_viz_ext_horMeanPtBar_brandList"),
			brandBar;
        
        svg.append("line")
            .attr("class", "sap_viz_ext_horMeanPtBar_depMeanLine")
            .attr("x1", x(newdataset.nest_data["BrandDependMean"]))
            .attr("x2", x(newdataset.nest_data["BrandDependMean"]))
            .attr("y1", 0)
            .attr("y2", plotHeight)
            .attr("stroke-dasharray", "10,10");	
			
		var tooltip = svg.append("g").attr("class", "sap_viz_ext_horMeanPtBar_tooltip");
			tooltip.append("rect").attr("class", "horMeanPtBar_tooltip_label");
			tooltip.append("clipPath").attr("id", "horMeanPtBar_tooltip_clip")
			.append("rect").attr("class", "horMeanPtBar_tooltip_label");
			// tooltip.append("rect").attr("class", "horMeanPtBar_tooltip_label");
			
		var tipcontent = tooltip.append("g").attr("class", "horMeanPtBar_tooltip_label_detail");
			tipcontent.append("text").attr("class", "tooltip_label_title").attr("clip-path", "url(#horMeanPtBar_tooltip_clip)");
			tipcontent.append("text").attr("class", "tooltip_label_info1").attr("clip-path", "url(#horMeanPtBar_tooltip_clip)");
			tipcontent.append("text").attr("class", "tooltip_label_info2").attr("clip-path", "url(#horMeanPtBar_tooltip_clip)");
		
		this.DrawBrandBar = function(){
			brandBar = brandList.selectAll(".sap_viz_ext_horMeanPtBar_brandBar")
	    		.data(newdataset.nest_data)
	    		.enter()
	    		.append("g")
	    		.attr("class", "sap_viz_ext_horMeanPtBar_brandBar")
	    		.attr("transform", function(d,i) { return "translate(0," + y(yBrandList[i]) + ")"; });
			
			brandBar.append("rect")
				.attr("class", "sap_viz_ext_horMeanPtBar_brandRect")
				.attr("width", plotWidth)
				.attr("height", y.rangeBand())
				.attr("x", "1")
				.attr("y", 0 )
				.attr("fill-opacity", "0.5")
				.style("fill", "#F5F5F5");
	          
			brandBar.append("rect")
				.attr("class", "sap_viz_ext_horMeanPtBar_depRangeScore")
				.attr("width", function(d){ return x(d["max_Depend"]) - x(d["min_Depend"]); })
				.attr("height", y.rangeBand())
				.attr("x", function(d){ return x(d["min_Depend"]); })
				.attr("y", 0 )
				.attr("fill-opacity", "0.7")
				.style("fill", "#086fad")
				.on('mouseover', function(d) {
					var thisRect = d3.select(this);
					    thisRect.attr('opacity', 0.8)
					    .attr("font-size", "1.4em").attr("font-weight", "bold");
					   
				    tooltip.attr("transform", function(){
				    	var leftBar = d3.select('.sapBiVaExplorerLeft'),
				    		rightBar = d3.select('.sapBiVaExplorerRight'),
                            topBar = d3.select('.sap-vi-desktop-app-roomselectorparent'),
                            topsubBar = d3.select('.sapBiVaExplorerTopToolbar');

				    	var leftOffset = leftBar[0][0] ? (rightBar[0][0] ? ( leftBar.node().getBoundingClientRect().width + rightBar.node().getBoundingClientRect().width ) : 0) : 0;
                        var topOffset = topBar[0][0] ? topBar.node().getBoundingClientRect().height : 0,
                            topsubOffset = topsubBar[0][0] ? topsubBar.node().getBoundingClientRect().height : 0;

					    var mouseX = d3.event.pageX - yAxisWidth - leftOffset - margin.left;
					    var mouseY = d3.event.pageY - topOffset - topsubOffset - margin.top * 2;
                        if(mouseX + 180 > plotWidth - yAxisWidth){
                            mouseX -= 180;
                        }
                        if(mouseY + 60 > plotHeight){
                            mouseY -= 70;
                        }
//                        console.log("MouseY " + d3.event.pageY + ", TOP offset " + (topOffset + topsubOffset));
//                        console.log("X " + mouseX + ", Y " + mouseY);
				    	return 	"translate(" + mouseX + "," + mouseY  + ")";
				    })
				    .style("opacity", 1);
					
					tooltip.select('#horMeanPtBar_tooltip_clip')
				        .attr("x", 0).attr("width", 200)
				        .attr("y",0) .attr("height", 60);
				        
				    tooltip.selectAll('.horMeanPtBar_tooltip_label')
				        .attr("x", 0).attr("width", function(d, i){
				        	return 220 - 20 * i;
				        })
				        .attr("y",0) .attr("height", 60)
				        .attr("rx", 2).attr("ry", 2)
				        .attr("opacity", .9);
				
				    tipcontent.select('.tooltip_label_title')
				        .attr("font-size", "1.2em")
				        .attr("dy","1.4em")
				        .attr("x", 10)
				        .text(dims[1] + ": " +  d.values.map(function(data){
				        	return data[dims[1]];
				        }).join() );
					
					tipcontent.select('.tooltip_label_info1')
				        .attr("dy","2.8em")
				        .attr("x", 10)
//				        .text(dims[2] + ": " + d.values.map(function(data){
//				        	return data[dims[2]];
//				        }).join());
                        .text(function(){
                            var str = [];
                            d.values.map(function(data, i){
                                if(i === 0){ str.push(data[dims[2]]); }
                                if(data[dims[2]] !== str[str.length-1]){
                                    str.push(data[dims[2]]);
                                }
                            });
                            // console.log(str);
                            return dims[2] + ": " + str.join();
                        });
                
					tipcontent.select('.tooltip_label_info2')
				        .attr("dy","4.2em")
				        .attr("x", 10)
				        .text("Min: " + d["min_Depend"] + ' / Mean: ' + d["mean_Depend"].toFixed(1) + ' / Max: ' + d["max_Depend"]);
                
					})
					.on('mouseout', function(){
					    d3.select(this).attr('opacity', 1)
					    .attr("font-size", "1.1em").attr("font-weight", "400");
					    // tooltip.style("opacity", 0);
					}); 
				// .style("fill", function(d){ return color(d.key); });
			
			brandBar.append("circle")
				.attr("class", "sap_viz_ext_horMeanPtBar_depMeanPoint")
				.attr("r", y.rangeBand() * .7 / 2)
				.attr("cx", function(d) { return x(d["mean_Depend"]); })
	    		.attr("cy", y.rangeBand()/2)
				.style("fill", "#FFE066");
            
		}; // DrawBrandBar()
		
		this.UpdateAxis = function(_plotWidth, _plotHeight, AxisOffset){
			x.rangeRound([0, _plotWidth]);
			y.rangeRoundBands([0, _plotHeight], .3);
			
			xAxis.scale(x);
			xAxisFullHeight.scale(x);
			yAxis.scale(y);
			
			xAxisContainer.call(xAxis);
			xAxisHintContainer.call(xAxisFullHeight);
			yAxisContainer.call(yAxis);
			
			svg.select(".sap_viz_ext_horMeanPtBar_depMeanLine")
				.attr("x1", x(newdataset.xMeanVal))
				.attr("x2", x(newdataset.xMeanVal));
				
			var hintTittle = xAxisContainer.append("g").attr("width", _plotWidth);

			hintTittle.append("text")
				.attr("class", "x_axis_percentTittle")
				.attr("dy", "-2em")
				.attr("dx", "50%")
				.attr("fill", "#333")
				.text(percentTittle);
			
			container.select(".sap_viz_ext_hormeanptbar")
				.attr("transform", "translate(" + AxisOffset + "," + margin.top + ")");
		};
		
		this.UpdateBrandBar = function(_plotWidth){
			var brandBarRect = brandBar.selectAll(".sap_viz_ext_horMeanPtBar_brandRect");
			var brandBarItem = brandBar.selectAll(".sap_viz_ext_horMeanPtBar_depRangeScore");
			var brandBarPoint = brandBar.selectAll(".sap_viz_ext_horMeanPtBar_depMeanPoint");
			
			brandBarRect.attr("width", _plotWidth);
			brandBarItem.attr("width", function(d){ return x(d["max_Depend"]) - x(d["min_Depend"]); })
				.attr("x", function(d){ return x(d["min_Depend"]); });
			brandBarPoint.attr("cx", function(d) { return x(d["mean_Depend"]); });
			
			color.domain(data.map(function(d) {
				return d[dims[2]]; 
			}));
			// console.log(color.domain());
		};
		
	}
	}; // render()

	return render;
});