var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.hormeanptbar": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);