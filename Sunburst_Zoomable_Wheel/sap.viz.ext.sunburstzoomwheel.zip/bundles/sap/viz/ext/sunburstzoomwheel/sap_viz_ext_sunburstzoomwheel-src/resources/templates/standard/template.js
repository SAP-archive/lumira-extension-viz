var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.sunburstzoomwheel": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);