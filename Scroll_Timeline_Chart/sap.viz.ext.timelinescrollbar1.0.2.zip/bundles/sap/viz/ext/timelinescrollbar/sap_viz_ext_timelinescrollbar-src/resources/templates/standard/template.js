var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.timelinescrollbar": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);