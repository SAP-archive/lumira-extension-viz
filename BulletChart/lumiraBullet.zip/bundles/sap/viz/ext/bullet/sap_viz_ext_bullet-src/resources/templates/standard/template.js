var sampleTemplate = 
{
    "id": "standard",
    "name": "Standard",
    "properties": {
        "sap.viz.ext.bullet": {
            
        }
    }
};
sap.viz.extapi.env.Template.register(sampleTemplate);