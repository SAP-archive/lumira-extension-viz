var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.bulletchart": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);