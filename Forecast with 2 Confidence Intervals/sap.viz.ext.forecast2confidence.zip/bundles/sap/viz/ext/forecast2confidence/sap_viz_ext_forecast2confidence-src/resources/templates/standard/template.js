var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.forecast2confidence": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);