var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.powerflowmaps": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);