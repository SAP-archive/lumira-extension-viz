var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.sunbrustclockswitch": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);