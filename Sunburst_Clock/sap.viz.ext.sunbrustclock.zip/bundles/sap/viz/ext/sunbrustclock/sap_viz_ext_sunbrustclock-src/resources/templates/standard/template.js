var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.sunbrustclock": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);