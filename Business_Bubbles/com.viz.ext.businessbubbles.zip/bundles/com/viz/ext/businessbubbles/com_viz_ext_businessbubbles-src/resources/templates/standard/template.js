var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"com.viz.ext.businessbubbles": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);