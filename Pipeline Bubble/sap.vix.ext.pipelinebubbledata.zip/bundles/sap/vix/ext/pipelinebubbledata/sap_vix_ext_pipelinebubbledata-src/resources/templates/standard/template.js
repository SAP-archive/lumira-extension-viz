var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.vix.ext.pipelinebubbledata": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);