var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.pipelinebubblemeadim": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);