var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.forecastsingleconfidence": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);