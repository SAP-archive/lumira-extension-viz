define("sap_viz_ext_swotanalysiscstprp-src/js/propertyeditor/spec", ["sap_viz_ext_swotanalysiscstprp-src/js/propertyeditor/renderers/checkbox"], function(checkBoxRenderer) {
	//property editor spec
	var spec = {
		"id": "sample.openpe.extension",
		"dependencies": [],
		"components": [{
			"id": "sample.openpe.swotanalysiscstprp.extension",
			"provide": "sap.viz.controls.propertyeditor.view",
			"instance": {
				'charts': ['sap.viz.ext.swotanalysiscstprp'],
				'view': {
					'sections': [{
						"id": "sap.viz.controls.propertyeditor.section.plotArea",
						"caption": 'EXTEND_PLOTAREA',
						'propertyZone': 'PLOTAREA',
						"groups": [{
							"id": "sap.viz.controls.propertyeditor.section.plotArea.group.topleft.color",
							'renderer': checkBoxRenderer,
							"config": {
								"property": "plotArea.topleft.color",
								"label": "Top Left Color: #",
								"layoutId": "tlLayoutId",
								"labelId": "tlLabelId",
								"fieldId": "tlFieldId"
								
							}
						}, {
							"id": "sap.viz.controls.propertyeditor.section.plotArea.group.topright.color",
							'renderer': checkBoxRenderer,
							"config": {
								"property": "plotArea.topright.color",
								"label": "Top Right Color: #",
								"layoutId": "trLayoutId",
								"labelId": "trLabelId",
								"fieldId": "trFieldId"
							}
						}, {
							"id": "sap.viz.controls.propertyeditor.section.plotArea.group.bottomleft.color",
							'renderer': checkBoxRenderer,
							"config": {
								"property": "plotArea.bottomleft.color",
								"label": "Bottom Left Color: #",
								"layoutId": "blLayoutId",
								"labelId": "blLabelId",
								"fieldId": "blFieldId"
							}
						}, {
							"id": "sap.viz.controls.propertyeditor.section.plotArea.group.bottomright.color",
							'renderer': checkBoxRenderer,
							"config": {
								"property": "plotArea.bottomright.color",
								"label": "Bottom Right Color: #",
								"layoutId": "brLayoutId",
								"labelId": "brLabelId",
								"fieldId": "brFieldId"
							}
						}]
					}, {
						"id": "sap.viz.controls.propertyeditor.section.legend",
						"caption": 'EXTEND_LEGEND',
						"propertyZone": "LEGEND",
						"groups": [{
							"id": "sap.viz.controls.propertyeditor.section.legend.group.legend.visible",
							"type": "sap.viz.controls.propertyeditor.groupImpl.SwitchGroup",
							"config": {
								"property": "legend.visible",
								"label": "PROPERTY_EDITOR_SHOW_LEGEND"
							}
						}, {
							"id": "sap.viz.controls.propertyeditor.section.legend.group.legend.title.visible",
							"type": "sap.viz.controls.propertyeditor.groupImpl.SwitchGroup",
							"config": {
								"property": "legend.title.visible",
								"label": "PROPERTY_EDITOR_SHOW_LEGEND_TITLE",
								"visibleBinding": "legend.visible"
							}
						}]
					}, {
						'id': 'sap.viz.controls.propertyeditor.section.colorSection',
						'propertyZone': 'COLORSECTION',
						'caption': 'EXTEND_COLORSECTION',
						"groups": [{
							"id": "sap.viz.controls.propertyeditor.section.colorSection.group.colorPalette",
							'renderer': checkBoxRenderer,
							"config": {
								"property": "colorSection.group.colorPalette.topleft",
								"label": "Top Left #",
								"layoutId": "tlLayoutId",
								"labelId": "tlLabelId",
								"fieldId": "tlFieldId"
							}
						}]
					}]
				}
			}
		}]
	};
	return spec;
});