sap.viz.extapi.env.Language.register({
	id: 'language',
	value: {
		EXTEND_CHART_TITLE: "Extend Chart Title",
		EXTEND_LEGEND: "Extend Legend",
		EXTEND_PLOT_AREA: "Extend Plot Area"
	}
});