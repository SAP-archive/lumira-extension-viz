var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.swotanalysiscstprp": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);