define("sap_viz_ext_swotanalysiscstprp-src/js/propertyeditor/renderers/checkbox", [], function() {
	var buildPropertyTree = function(path, value) {
		var ret = {};
		if (!path || !path.length) {
			return ret;
		}
		var current = ret,
			pathArray = path.split(".");
		for (var i = 0, len = pathArray.length; i < len; i++) {
			if (i === len - 1) {
				current[pathArray[i]] = value;
			} else {
				current[pathArray[i]] = {};
				current = current[pathArray[i]];
			}
		}
		return ret;
	};

	var readProperty = function(obj, path) {
		if (!path || !path.length) {
			return obj;
		}
		var current = obj,
			pathArray = path.split(".");
		for (var i = 0, len = pathArray.length; i < len; i++) {
			if (!current) {
				return undefined;
			} else if (i === len - 1) {
				return current[pathArray[i]];
			} else {
				current = current[pathArray[i]];
			}
		}
		return undefined;
	};

	var checkBoxRenderer = function(div, proxy, config) {
		// create a simple CheckBox
		console.log(config);
		var oLayout = new sap.ui.commons.layout.MatrixLayout({id: config.layoutId, layoutFixed:false});

		var oLabel, oText;
        var defaultColors = ["#BDD673", "#91C1E8", "#E07A5E", "#D8AFD6"];
		
		oLayout.createRow(
		
			oLabel = new sap.ui.commons.Label({ id : config.labelId, text: config.label , labelFor:"firstName"}),
			
			oText = new sap.ui.commons.TextField({
				id: config.fieldId, 
				required:false, 
				maxLength: 6, 
				value: defaultColors[config.fieldId - 1], 
				width: "60px",
				liveChange: function(oEvent) {
					proxy.updateProperties(buildPropertyTree(config.property, oEvent.getParameter("liveValue")));
				}
			})
		
		);
		
		oLayout.placeAt($(div));
	};

	return checkBoxRenderer;
});