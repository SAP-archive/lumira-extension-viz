var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.linechartzoom": {
			"legend": {
				"title": {
					"visible": true
				}
			}
		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);