var sampleTemplate = 
{
    "id": "standard",
    "name": "Standard",
    "properties": {
        "sap.viz.ext.footballheatmap": {
            "legend": {
                "title": {
                    "visible": true
                }
            }
        }
    }
};
sap.viz.extapi.env.Template.register(sampleTemplate);