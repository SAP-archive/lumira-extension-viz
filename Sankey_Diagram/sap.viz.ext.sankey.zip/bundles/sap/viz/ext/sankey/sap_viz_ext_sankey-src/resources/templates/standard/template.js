var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.sankey": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);