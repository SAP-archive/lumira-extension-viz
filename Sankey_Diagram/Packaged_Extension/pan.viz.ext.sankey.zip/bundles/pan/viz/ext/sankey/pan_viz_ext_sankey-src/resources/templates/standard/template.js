var sampleTemplate = 
{
    "id": "standard",
    "name": "Standard",
    "properties": {
        "pan.viz.ext.sankey": {
            
        }
    }
};
sap.viz.extapi.env.Template.register(sampleTemplate);