var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.quadrant": {
			"legend": {
				"title": {
					"visible": true
				}
			}
		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);