var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.populationpyramid": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);