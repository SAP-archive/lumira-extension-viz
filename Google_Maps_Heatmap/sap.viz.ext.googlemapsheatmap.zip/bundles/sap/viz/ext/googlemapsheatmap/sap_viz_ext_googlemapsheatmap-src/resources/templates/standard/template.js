var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.googlemapsheatmap": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);