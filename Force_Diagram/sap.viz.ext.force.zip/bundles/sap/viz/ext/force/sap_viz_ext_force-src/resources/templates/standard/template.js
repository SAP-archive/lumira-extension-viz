var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"sap.viz.ext.force": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);