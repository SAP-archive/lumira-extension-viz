var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"siesta.saphackathon.viz.ext.bounceball": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);